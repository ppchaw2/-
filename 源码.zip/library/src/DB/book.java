package DB;

public class book {
private int bookid;
private String book_name;
private String author;
private String publisher;
private String state;
private String other_info;
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getBook_name() {
	return book_name;
}
public void setBook_name(String book_name) {
	this.book_name = book_name;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public String getPublisher() {
	return publisher;
}
public void setPublisher(String publisher) {
	this.publisher = publisher;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getOther_info() {
	return other_info;
}
public void setOther_info(String other_info) {
	this.other_info = other_info;
}

}
